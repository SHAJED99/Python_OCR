from PyQt5 import QtCore, QtGui, QtWidgets
import cv2
from F_ImageProcess import DrawRectangle
from Main_3 import Ui_MainWindow

Image_Location = None
QPMap_Rectangle = None
contours = None
thresh = None

Window_Image_width = 600
Window_Image_height = 500
Default_Max_Area_Count = 100

class Ui_SecondWindow(object):
    def __init__(self, location):
        global Image_Location
        Image_Location = location
        Image_Process(Image_Location)

    def setupUi(self, SecondWindow):
        global QPMap_Rectangle
        SecondWindow.setObjectName("SecondWindow")
        SecondWindow.resize(Window_Image_width+20, Window_Image_height+30+58)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("Main.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        SecondWindow.setWindowIcon(icon)
        self.centralwidget = QtWidgets.QWidget(SecondWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(10, 10, Window_Image_width, Window_Image_height+5))
        self.label_2.setStyleSheet("border-style: solid;\n"
"border-width: 1px;\n"
"border-color: rgb(225, 225, 225);")
        self.label_2.setText("")
        self.label_2.setPixmap(QtGui.QPixmap(QPMap_Rectangle))
        self.label_2.setAlignment(QtCore.Qt.AlignCenter)
        self.label_2.setObjectName("label_2")
        self.widget = QtWidgets.QWidget(self.centralwidget)
        self.widget.setGeometry(QtCore.QRect(10, Window_Image_height+10, Window_Image_width, 58))
        self.widget.setObjectName("widget")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.widget)
        self.verticalLayout.setSizeConstraint(QtWidgets.QLayout.SetDefaultConstraint)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setSpacing(0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.label = QtWidgets.QLabel(self.widget)
        font = QtGui.QFont()
        font.setPointSize(11)
        font.setBold(True)
        font.setUnderline(False)
        font.setWeight(75)
        font.setStrikeOut(False)
        self.label.setFont(font)
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        self.label.setObjectName("label")
        self.verticalLayout.addWidget(self.label)
        self.gridLayout = QtWidgets.QGridLayout()
        self.gridLayout.setObjectName("gridLayout")
        self.pushButton = QtWidgets.QPushButton(self.widget)
        self.pushButton.setObjectName("pushButton")
        self.gridLayout.addWidget(self.pushButton, 0, 0, 1, 1)
        self.pushButton.clicked.connect(lambda : self.Okay(SecondWindow))
        self.pushButton_2 = QtWidgets.QPushButton(self.widget)
        self.pushButton_2.setObjectName("pushButton_2")
        self.gridLayout.addWidget(self.pushButton_2, 0, 1, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout)
        SecondWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(SecondWindow)
        self.statusbar.setObjectName("statusbar")
        SecondWindow.setStatusBar(self.statusbar)

        self.retranslateUi(SecondWindow)
        QtCore.QMetaObject.connectSlotsByName(SecondWindow)

    def retranslateUi(self, SecondWindow):
        _translate = QtCore.QCoreApplication.translate
        SecondWindow.setWindowTitle(_translate("SecondWindow", "Image to Text"))
        self.label.setText(_translate("SecondWindow", "Text selection?"))
        self.pushButton.setText(_translate("SecondWindow", "Okay"))
        self.pushButton_2.setText(_translate("SecondWindow", "Let me select"))

    def Okay(self, SecondWindow):
        self.window = QtWidgets.QMainWindow()
        self.ui = Ui_MainWindow(Image_Location, contours, QPMap_Rectangle, Window_Image_width, Window_Image_height, Default_Max_Area_Count, thresh)
        self.ui.setupUi(self.window)
        SecondWindow.hide()
        self.window.show()


def Image_Process(location):
    global QPMap_Rectangle, contours, thresh
    image = cv2.imread(location)
    QPMap_Rectangle, contours, thresh = DrawRectangle(image, Window_Image_width, Window_Image_height, Default_Max_Area_Count)


