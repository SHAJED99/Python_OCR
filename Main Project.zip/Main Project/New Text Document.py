# from PyQt5 import QtCore, QtGui, QtWidgets
# from PyQt5.QtGui import QPainter, QBrush, QPen
# from PyQt5.QtCore import Qt
# from PyQt5.QtWidgets import QApplication, QMainWindow
# from F_ImageProcess import ResizeImage, Counters
# import  cv2
#
#
# class Window(QMainWindow):
#     def __init__(self):
#         super().__init__()
#
#         self.title = "PyQt5 Drawing Rectangle"
#         self.top = 100
#         self.left = 100
#         self.width = 680
#         self.height = 500
#
#
#         self.InitWindow()
#
#
#     def InitWindow(self):
#         self.setWindowIcon(QtGui.QIcon("icon.png"))
#         self.setWindowTitle(self.title)
#         self.setGeometry(self.top, self.left, self.width, self.height)
#         self.show()
#
#
#     def paintEvent(self, e):
#         painter = QPainter(self)
#         painter.setPen(QPen(Qt.black, 5, Qt.SolidLine))
#         #painter.setBrush(QBrush(Qt.red, Qt.SolidPattern))
#         painter.setBrush(QBrush(Qt.green, Qt.DiagCrossPattern))
#
#         painter.drawRect(100, 15, 400, 200)
#
#
#
# App = QApplication(sys.argv)
# window = Window()
# sys.exit(App.exec())


# class QtCapture(QtGui.QWid):
#     def __init__(self, *args):
#         super(QtGui.QWidgets, self).__init__()
#
#         self.fps = 24
#         self.cap = cv2.VideoCapture(*args)
#
#         self.video_frame = QtGui.QLabel()
#         lay = QtGui.QVBoxLayout()
#         lay.setMargin(0)
#         lay.addWidget(self.video_frame)
#         self.setLayout(lay)
#
#     def setFPS(self, fps):
#         self.fps = fps
#
#     def nextFrameSlot(self):
#         ret, frame = self.cap.read()
#         # OpenCV yields frames in BGR format
#         frame = cv2.cvtColor(frame, cv2.cv.CV_BGR2RGB)
#         img = QtGui.QImage(frame, frame.shape[1], frame.shape[0], QtGui.QImage.Format_RGB888)
#         pix = QtGui.QPixmap.fromImage(img)
#         self.video_frame.setPixmap(pix)
#
#     def start(self):
#         self.timer = QtCore.QTimer()
#         self.timer.timeout.connect(self.nextFrameSlot)
#         self.timer.start(1000./self.fps)
#
#     def stop(self):
#         self.timer.stop()
#
#     def deleteLater(self):
#         self.cap.release()
#         super(QtGui.QWidgets, self).deleteLater()
#
#
import sys
# from PyQt5 import QtCore, QtWidgets
#
#
# class MainWindow(QtWidgets.QWidget):
#
#     switch_window = QtCore.pyqtSignal(str)
#
#     def __init__(self):
#         QtWidgets.QWidget.__init__(self)
#         self.setWindowTitle('Main Window')
#
#         layout = QtWidgets.QGridLayout()
#
#         self.line_edit = QtWidgets.QLineEdit()
#         layout.addWidget(self.line_edit)
#
#         self.button = QtWidgets.QPushButton('Switch Window')
#         self.button.clicked.connect(self.switch)
#         layout.addWidget(self.button)
#
#         self.setLayout(layout)
#
#     def switch(self):
#         print(self.line_edit.text())
#         self.switch_window.emit(self.line_edit.text())
#
#
# class WindowTwo(QtWidgets.QWidget):
#
#     def __init__(self, text):
#         QtWidgets.QWidget.__init__(self)
#         self.setWindowTitle('Window Two')
#
#         layout = QtWidgets.QGridLayout()
#
#         self.label = QtWidgets.QLabel(text)
#         layout.addWidget(self.label)
#
#         self.button = QtWidgets.QPushButton('Close')
#         self.button.clicked.connect(self.close)
#
#         layout.addWidget(self.button)
#
#         self.setLayout(layout)
#
#
# class Login(QtWidgets.QWidget):
#
#     switch_window = QtCore.pyqtSignal()
#
#     def __init__(self):
#         QtWidgets.QWidget.__init__(self)
#         self.setWindowTitle('Login')
#
#         layout = QtWidgets.QGridLayout()
#
#         self.button = QtWidgets.QPushButton('Login')
#         self.button.clicked.connect(self.login)
#
#         layout.addWidget(self.button)
#
#         self.setLayout(layout)
#
#     def login(self):
#         self.switch_window.emit()
#
#
# class Controller:
#
#     def __init__(self):
#         pass
#
#     def show_login(self):
#         self.login = Login()
#         self.login.switch_window.connect(self.show_main)
#         self.login.show()
#
#     def show_main(self):
#         self.window = MainWindow()
#         self.window.switch_window.connect(self.show_window_two)
#         self.login.close()
#         self.window.show()
#
#     def show_window_two(self, text):
#         print(text)
#         self.window_two = WindowTwo(text)
#         self.window.close()
#         self.window_two.show()
#
#
# def main():
#     app = QtWidgets.QApplication(sys.argv)
#     controller = Controller()
#     controller.show_login()
#     sys.exit(app.exec_())
#
#
# if __name__ == '__main__':
#     main()


# import numpy as np
# f=open('asd.dat','a')
# for iind in range(4):
#     a=np.random.rand(10,10)
#     np.savetxt(f,a)
# f.close()

# from PyQt5 import QtCore, QtGui, QtWidgets
# import sys
#
#
# class Ui_MainWindow(QtWidgets.QWidget):
#     def setupUi(self, MainWindow):
#         MainWindow.resize(422, 255)
#         self.centralwidget = QtWidgets.QWidget(MainWindow)
#
#         self.pushButton = QtWidgets.QPushButton(self.centralwidget)
#         self.pushButton.setGeometry(QtCore.QRect(160, 130, 93, 28))
#
#         # For displaying confirmation message along with user's info.
#         self.label = QtWidgets.QLabel(self.centralwidget)
#         self.label.setGeometry(QtCore.QRect(170, 40, 201, 111))
#
#         # Keeping the text of label empty initially.
#         self.label.setText("")
#
#         MainWindow.setCentralWidget(self.centralwidget)
#         self.retranslateUi(MainWindow)
#         QtCore.QMetaObject.connectSlotsByName(MainWindow)
#
#     def retranslateUi(self, MainWindow):
#         _translate = QtCore.QCoreApplication.translate
#         MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
#         self.pushButton.setText(_translate("MainWindow", "Proceed"))
#         self.pushButton.clicked.connect(self.takeinputs)
#
#     def takeinputs(self):
#         name, done1 = QtWidgets.QInputDialog.getText(
#             self, 'Input Dialog', 'Enter your name:')
#
#         roll, done2 = QtWidgets.QInputDialog.getInt(
#             self, 'Input Dialog', 'Enter your roll:')
#
#         cgpa, done3 = QtWidgets.QInputDialog.getDouble(
#             self, 'Input Dialog', 'Enter your CGPA:')
#
#         langs = ['C', 'c++', 'Java', 'Python', 'Javascript']
#         lang, done4 = QtWidgets.QInputDialog.getItem(
#             self, 'Input Dialog', 'Language you know:', langs)
#
#         if done1 and done2 and done3 and done4:
#             # Showing confirmation message along
#             # with information provided by user.
#             self.label.setText('Information stored Successfully\nName: '
#                                + str(name) + '(' + str(roll) + ')' + '\n' + 'CGPA: '
#                                + str(cgpa) + '\nSelected Language: ' + str(lang))
#
#             # Hide the pushbutton after inputs provided by the use.
#             self.pushButton.hide()
#
#
# if __name__ == "__main__":
#     app = QtWidgets.QApplication(sys.argv)
#     MainWindow = QtWidgets.QMainWindow()
#     ui = Ui_MainWindow()
#     ui.setupUi(MainWindow)
#     MainWindow.show()
#
#     sys.exit(app.exec_())

import sys
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QMainWindow, QWidget, QLabel, QLineEdit
from PyQt5.QtWidgets import QPushButton
from PyQt5.QtCore import QSize
#
# class MainWindow(QMainWindow):
#     def __init__(self):
#         QMainWindow.__init__(self)
#
#         self.setMinimumSize(QSize(320, 140))
#         self.setWindowTitle("PyQt Line Edit example (textfield) - pythonprogramminglanguage.com")
#
#         self.nameLabel = QLabel(self)
#         self.nameLabel.setText('Name:')
#         self.line = QLineEdit(self)
#
#         self.line.move(80, 20)
#         self.line.resize(200, 32)
#         self.nameLabel.move(20, 20)
#
#         pybutton = QPushButton('OK', self)
#         pybutton.clicked.connect(self.clickMethod)
#         pybutton.resize(200,32)
#         pybutton.move(80, 60)
#
#     def clickMethod(self):
#         self.line.text()
#         # print('Your name: ' + self.line.text())
#         MainWindow.hide(self)
#
# if __name__ == "__main__":
#     app = QtWidgets.QApplication(sys.argv)
#     mainWin = MainWindow()
#     mainWin.show()
#     sys.exit( app.exec_() )

# import sys
# from PyQt5.QtWidgets import QApplication, QMainWindow, QLabel, QComboBox, QPushButton
#
#
# class Example(QMainWindow):
#
#     def __init__(self):
#         super().__init__()
#
#         combo = QComboBox(self)
#         combo.addItem("Apple")
#         combo.addItem("Pear")
#         combo.addItem("Lemon")
#
#         combo.move(50, 50)
#
#         self.qlabel = QLabel(self)
#         self.qlabel.move(50, 16)
#
#         print(combo.activated[int].connect(self.onChanged))
#
#         self.setGeometry(50, 50, 320, 200)
#         self.setWindowTitle("QLineEdit Example")
#         self.show()
#
#     def onChanged(self, text):
#         print(text, end=" ")
#         self.qlabel.setText(str(text))
#         self.qlabel.adjustSize()
#         return
#
#
# if __name__ == '__main__':
#     app = QApplication(sys.argv)
#     ex = Example()
#     sys.exit(app.exec_())

# St = ["abc", "bcd", "cde"]
# it = [1, 2, 10, 100]
#
# for i in St:
#     print(i)
# for c in it:
#     print(c)

# import numpy as np
# import collections
#
# # a = [48.0,255.0,255.0,4.0,148.0,255.0,186.0,2.0,0.0,0.0,0.0,0.0,2.0,186.0,255.0,148.0,4.0,255.0,255.0,48.0,255.0,255.0,255.0,255.0,255.0,255.0,255.0,96.0,0.0,0.0,0.0,0.0,96.0,255.0,255.0,255.0,255.0,255.0,255.0,255.0,237.0,255.0,255.0,255.0,255.0,255.0,234.0,88.0,0.0,0.0,0.0,0.0,88.0,234.0,255.0,255.0,255.0,255.0,245.0,234.0,39.0,225.0,225.0,255.0,255.0,227.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,255.0,255.0,255.0,225.0,118.0,0.0,0.0,0.0,0.0,255.0,255.0,54.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,255.0,255.0,225.0,0.0,0.0,0.0,0.0,0.0,0.0,219.0,255.0,255.0,34.0,0.0,0.0,0.0,0.0,0.0,0.0,34.0,255.0,255.0,57.0,0.0,0.0,0.0,0.0,0.0,0.0,57.0,255.0,255.0,185.0,0.0,0.0,0.0,0.0,0.0,21.0,200.0,255.0,231.0,45.0,0.0,0.0,0.0,0.0,0.0,0.0,43.0,228.0,255.0,202.0,24.0,0.0,0.0,0.0,0.0,95.0,255.0,255.0,147.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,105.0,250.0,255.0,141.0,2.0,0.0,0.0,2.0,141.0,255.0,250.0,105.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,236.0,255.0,255.0,6.0,0.0,0.0,85.0,255.0,255.0,161.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,153.0,255.0,255.0,93.0,0.0,0.0,255.0,255.0,255.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,184.0,255.0,255.0,0.0,66.0,255.0,255.0,184.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,70.0,255.0,255.0,106.0,206.0,255.0,215.0,41.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,39.0,212.0,255.0,255.0,255.0,255.0,159.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,82.0,252.0,255.0,255.0,252.0,82.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,248.0,255.0,255.0,120.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,112.0,255.0,255.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,255.0,255.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,255.0,255.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,255.0,255.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,255.0,255.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,255.0,255.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,255.0,255.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,255.0,255.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,255.0,255.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,255.0,255.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,130.0,225.0,163.0,0.0,220.0,255.0,255.0,0.0,0.0,163.0,225.0,130.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,53.0,246.0,255.0,249.0,234.0,254.0,255.0,255.0,234.0,234.0,249.0,255.0,246.0,53.0,0.0,0.0,0.0,0.0,0.0,0.0,57.0,255.0,255.0,255.0,255.0,255.0,255.0,255.0,255.0,255.0,255.0,255.0,255.0,57.0,0.0,0.0,0.0,0.0,0.0,0.0,1.0,148.0,255.0,255.0,255.0,10.0,4.0,4.0,10.0,255.0,255.0,255.0,148.0,1.0,0.0,0.0,0.0]
# a = [0.0,31.0,255.0,255.0,255.0,255.0,255.0,255.0,255.0,255.0,255.0,255.0,255.0,255.0,255.0,255.0,255.0,255.0,255.0,19.0,43.0,255.0,255.0,255.0,255.0,255.0,255.0,255.0,255.0,255.0,255.0,255.0,255.0,255.0,255.0,255.0,255.0,255.0,255.0,255.0,255.0,255.0,255.0,255.0,241.0,191.0,212.0,255.0,255.0,255.0,255.0,255.0,255.0,212.0,191.0,191.0,244.0,255.0,255.0,255.0,255.0,255.0,255.0,239.0,128.0,0.0,54.0,166.0,166.0,166.0,166.0,166.0,166.0,54.0,0.0,0.0,210.0,255.0,255.0,255.0,143.0,255.0,255.0,210.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,210.0,255.0,255.0,143.0,6.0,255.0,237.0,95.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,210.0,255.0,255.0,6.0,2.0,89.0,78.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,128.0,239.0,255.0,255.0,6.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,197.0,255.0,255.0,78.0,2.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,197.0,255.0,255.0,19.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,176.0,252.0,255.0,255.0,19.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,185.0,255.0,255.0,32.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,26.0,195.0,255.0,255.0,32.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,172.0,255.0,255.0,202.0,24.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,172.0,255.0,255.0,44.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,72.0,209.0,255.0,255.0,45.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,159.0,255.0,255.0,255.0,45.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,159.0,255.0,255.0,127.0,16.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,110.0,231.0,255.0,255.0,57.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,146.0,255.0,255.0,255.0,57.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,147.0,255.0,255.0,79.0,3.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,134.0,255.0,255.0,255.0,70.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,134.0,255.0,255.0,229.0,60.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,134.0,255.0,255.0,83.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,42.0,176.0,255.0,255.0,83.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,121.0,255.0,255.0,183.0,46.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,121.0,255.0,255.0,96.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,70.0,208.0,255.0,255.0,95.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,108.0,255.0,255.0,255.0,95.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,108.0,255.0,255.0,255.0,96.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,5.0,128.0,255.0,115.0,5.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0]
#
# try:
#     Pre_npaClassifications = np.loadtxt("classifications.txt", np.float32)
#     Pre_npaClassifications = Pre_npaClassifications.reshape((Pre_npaClassifications.size, 1))
#     Pre_npaFlattenedImages = np.loadtxt("flattened_images.txt", np.float32)
#
#     print(Pre_npaClassifications[1])
#
#     print(len(Pre_npaFlattenedImages))
#
#     index = list(collections.Counter(np.where(Pre_npaFlattenedImages == a)[0]).values()).index(len(a))
#
#     print(index)
#
#     # print(Pre_npaFlattenedImages[1])
#     # print(len(Pre_npaFlattenedImages[1]))
#
#     # for i in r:
#     #     print(i)
#
#
#
# except ValueError:
#     print(ValueError)

# from PyQt5.QtWidgets import (QLineEdit, QVBoxLayout, QMainWindow,
#     QWidget, QDesktopWidget, QApplication, QPushButton, QLabel,
#     QComboBox, QFileDialog, QRadioButton)
# from PyQt5.QtCore import pyqtSlot, QByteArray
# from PyQt5.QtGui import QPixmap
#
# from PyQt5 import QtGui, QtCore
#
# class Window2(QMainWindow):
#     def __init__(self):
#         super().__init__()
#         self.initPopup()
#
#     def initPopup(self):
#         self.resize(500, 500)
#         self.setWindowTitle("Window22222")
#         self.central_widget = QWidget()
#         self.setCentralWidget(self.central_widget)
#         lay = QVBoxLayout(self.central_widget)
#
#         label = QLabel(self)
#         pixmap = QPixmap('cropped/8.png')
#         label.setPixmap(pixmap)
#         self.resize(pixmap.width(), pixmap.height())
#
#         lay.addWidget(label)
#
#         self.textbox = QLineEdit(self)
#         self.textbox.move(20, 20)
#         self.textbox.resize(280, 40)
#
#         # Create a button in the window
#         self.button = QPushButton('Show text', self)
#         self.button.move(20, 80)
#         # connect button to function on_click
#         self.button.clicked.connect(lambda: self.on_clickX())
#         self.show()
#
#     @pyqtSlot()
#     def on_clickX(self):
#         textboxValue = self.textbox.text()
#         print(textboxValue)
#         self.textbox.setText("")
#         self.hide()
#
#
#
# def test(self):
#     for x in range(6):
#         w = Window2()
#
# class SG(QWidget):
#     def __init__(self):
#         super().__init__()
#         self.initUI()
#
#     def initUI(self):
#         self.resize(300, 150)
#         self.setWindowTitle('TEST')
#
#         self.resultsGen = QPushButton('TEST', self)
#         self.resultsGen.clicked.connect(lambda: self.on_click())
#
#         self.show()
#
#     @pyqtSlot()
#     def on_click(self):
#         test(self)
#
# if __name__ == '__main__':
#     app = QApplication(sys.argv)
#     sg = SG()
#
#     sys.exit(app.exec_())

from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *

import time


class MainWindow(QMainWindow):

    def __init__(self, *args, **kwargs):
        super(MainWindow, self).__init__(*args, **kwargs)

        self.counter = 0

        layout = QVBoxLayout()

        self.l = QLabel("Start")
        b = QPushButton("DANGER!")
        b.pressed.connect(self.oh_no)

        layout.addWidget(self.l)
        layout.addWidget(b)

        w = QWidget()
        w.setLayout(layout)

        self.setCentralWidget(w)

        self.show()

        self.timer = QTimer()
        self.timer.setInterval(1000)
        self.timer.timeout.connect(self.recurring_timer)
        self.timer.start()

    def oh_no(self):
        time.sleep(5)

    def recurring_timer(self):
        self.counter += 1
        self.l.setText("Counter: %d" % self.counter)


app = QApplication([])
window = MainWindow()
app.exec_()