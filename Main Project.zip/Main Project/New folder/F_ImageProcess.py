import cv2, heapq
from PyQt5.QtGui import QPixmap
import numpy as np
import operator
from PyQt5 import QtCore, QtGui

RESIZED_IMAGE_WIDTH = 20
RESIZED_IMAGE_HEIGHT = 30

class ContourWithData():
    changePixmap = QtCore.pyqtSignal(QtGui.QImage)

    npaContour = None
    boundingRect = None
    intRectX = 0
    intRectY = 0
    intRectWidth = 0
    intRectHeight = 0
    fltArea = 0.0

    def calculateRectTopLeftPointAndWidthAndHeight(self):
        [intX, intY, intWidth, intHeight] = self.boundingRect
        self.intRectX = intX
        self.intRectY = intY
        self.intRectWidth = intWidth
        self.intRectHeight = intHeight

def ResizeImage(image, Width, Height):
    # image = cv2.imread(Location, 1)
    if image is not None:
        rgbImage = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        convertToQtFormat = QtGui.QImage(rgbImage.data, rgbImage.shape[1], rgbImage.shape[0], QtGui.QImage.Format_RGB888)
        convertToQtFormat = QtGui.QPixmap.fromImage(convertToQtFormat)
        pixmap = QPixmap(convertToQtFormat)
        resizeImage = pixmap.scaled(Width, Height, QtCore.Qt.KeepAspectRatio)
        return resizeImage
    else:
        return None


def DrawRectangle(image, Width, Height, most_area=40):
    # image = cv2.imread(location)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (5, 5), 0)
    thresh = cv2.adaptiveThreshold(blur, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, 11, 2)
    thresh1 = thresh.copy()

    con, _ = cv2.findContours(thresh1, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    contours = []

    for contour in con:
        area = cv2.contourArea(contour)
        if area > most_area:
            cv2.drawContours(image, contour, -1, (255, 0, 0), 1)
            [x, y, w, h] = cv2.boundingRect(contour)
            cv2.rectangle(image, (x, y), (x + w, y + h), (0, 0, 255), 2)
            contours.append(contour)

    rgbImage = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    convertToQtFormat = QtGui.QImage(rgbImage.data, rgbImage.shape[1], rgbImage.shape[0], QtGui.QImage.Format_RGB888)
    convertToQtFormat = QtGui.QPixmap.fromImage(convertToQtFormat)
    pixmap = QPixmap(convertToQtFormat)
    resizeImage = pixmap.scaled(Width, Height, QtCore.Qt.KeepAspectRatio)

    return resizeImage, contours, thresh

def get_text(Contours, imgThresh):
    validContoursWithData = []
    kNearest = cv2.ml.KNearest_create()

    for npaContour in Contours:
        contourWithData = ContourWithData()
        contourWithData.npaContour = npaContour
        contourWithData.boundingRect = cv2.boundingRect(contourWithData.npaContour)
        contourWithData.calculateRectTopLeftPointAndWidthAndHeight()
        contourWithData.fltArea = cv2.contourArea(contourWithData.npaContour)
        validContoursWithData.append(contourWithData)

    validContoursWithData.sort(key=operator.attrgetter("intRectX"))

    try:
        npaClassifications = np.loadtxt("classifications.txt", np.float32)
        npaClassifications = npaClassifications.reshape((npaClassifications.size, 1))
    except:
        return None, validContoursWithData

    try:
        npaFlattenedImages = np.loadtxt("flattened_images.txt", np.float32)
        kNearest.train(npaFlattenedImages, cv2.ml.ROW_SAMPLE, npaClassifications)
    except:
        return None, validContoursWithData

    print(len(npaClassifications), len(npaFlattenedImages))

    print(npaClassifications, npaFlattenedImages)

    # for i in range(0, len(npaClassifications)):
    #     print(npaClassifications[i], end="  ")
    #     print(npaFlattenedImages[i])



    strFinalString = ""

    for contourWithData in validContoursWithData:
        imgROI = imgThresh[contourWithData.intRectY: contourWithData.intRectY + contourWithData.intRectHeight, contourWithData.intRectX: contourWithData.intRectX + contourWithData.intRectWidth]

        imgROIResized = cv2.resize(imgROI, (RESIZED_IMAGE_WIDTH, RESIZED_IMAGE_HEIGHT))
        npaROIResized = imgROIResized.reshape((1, RESIZED_IMAGE_WIDTH * RESIZED_IMAGE_HEIGHT))
        npaROIResized = np.float32(npaROIResized)

        retval, npaResults, neigh_resp, dists = kNearest.findNearest(npaROIResized, k=1)

        strCurrentChar = str(chr(int(npaResults[0][0])))
        strFinalString = strFinalString + strCurrentChar

    return strFinalString, validContoursWithData

def Draw_Single_Rectangle(Image, X, Y, W, H):
    Mini_Image_Size = 70
    Window_Image_width = 600
    Window_Image_height = 500
    Dup = Image.copy()
    cv2.rectangle(Image, (X, Y), (X + W, Y + H), (0, 0, 255), 2)
    Dup = Dup[Y:Y + H, X:X + W]

    resizeImage = ResizeImage(Image, Window_Image_width, Window_Image_height)
    resizeImage1 = ResizeImage(Dup, Mini_Image_Size, Mini_Image_Size)

    return resizeImage, resizeImage1

def Train_DB(text, validContoursWithData, imgTrainingNumbers):
    ALPH = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"
    W = 20
    H = 30
    intClassifications = []
    npaFlattenedImages = np.empty((0, W * H))
    imgGray = cv2.cvtColor(imgTrainingNumbers, cv2.COLOR_BGR2GRAY)
    imgBlurred = cv2.GaussianBlur(imgGray, (5, 5), 0)
    imgThresh = cv2.adaptiveThreshold(imgBlurred, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, 11, 2)


    c = 0
    for Text in text:
        intClassifications.append(ord(Text))

        intX = validContoursWithData[c].intRectX
        intY = validContoursWithData[c].intRectY
        intW = validContoursWithData[c].intRectWidth
        intH = validContoursWithData[c].intRectHeight
        imgROI = imgThresh[intY:intY + intH, intX:intX + intW]
        imgROIResized = cv2.resize(imgROI, (W, H))

        npaFlattenedImage = imgROIResized.reshape((1, W * H))
        npaFlattenedImages = np.append(npaFlattenedImages, npaFlattenedImage, 0)

        c = c + 1

    fltClassifications = np.array(intClassifications, np.float32)
    npaClassifications = fltClassifications.reshape((fltClassifications.size, 1))

    if save(npaClassifications, npaFlattenedImages) is True:
        return True
    else:
        return False

def String_Index_Change(string, position, character):
    return string[:position] + character + string[position+1:]

def Space_Remove(string):
    return string.replace("-", "")

def save(npaClassifications, npaFlattenedImages):
    try:
        npaClassifications = np.loadtxt("classifications.txt", np.float32)
        npaClassifications = npaClassifications.reshape((npaClassifications.size, 1))
    except:
        return False

    try:
        npaFlattenedImages = np.loadtxt("flattened_images.txt", np.float32)
    except:
        return False

    print(len(npaClassifications), len(npaFlattenedImages))
    print(npaClassifications, npaFlattenedImages)
    f = open("classifications.txt", "a")
    e = open("flattened_images.txt", "a")

    if f is not None and e is not None:
        np.savetxt(f, npaClassifications)
        np.savetxt(e, npaFlattenedImages)
        f.close()
        e.close()
        return True
    else:
        return False