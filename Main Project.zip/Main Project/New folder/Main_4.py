from PyQt5 import QtCore, QtGui, QtWidgets
import cv2
from F_ImageProcess import Draw_Single_Rectangle, Train_DB, String_Index_Change,Space_Remove
# from Main_1 import Ui_MainWindow

Input = None
Window_Image_width = 0
Window_Image_height = 0
Mini_Image_Size = 70
QPMap_Rectangle = None
QMini = None
Contours = []
Len_Contour = 0
Index = 0
image = None
Text = None
Text_Len = 0
ALPH = "-ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"
Index_validContoursWithData = []


class Main4(object):
    def __init__(self, Location, Con, Image_width, Image_height, text, validContoursWith):
        global Contours, Window_Image_width, Window_Image_height, image, Len_Contour, Text, Text_Len
        Window_Image_width = Image_width
        Window_Image_height = Image_height

        Text = text
        if Text is None:
            Text = str()
            Text_Len = 0
        else:
            Text_Len = len(Text)

        image = cv2.imread(Location)
        Len_Contour = len(Con)
        Contours = validContoursWith
        self.Set_Image_In_Window(Index)

    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(Window_Image_width + 20, Window_Image_height + 20 + 20 + 31)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("Main.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        MainWindow.setWindowIcon(icon)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(10, 10, Window_Image_width, Window_Image_height))
        self.label.setStyleSheet("border-style: solid;\n"
"border-width: 1px;\n"
"border-color: rgb(225, 225, 225);")
        self.label.setText("")
        self.label.setObjectName("label")
        self.label.setPixmap(QtGui.QPixmap(QPMap_Rectangle))
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(10, 10, Mini_Image_Size, Mini_Image_Size))
        self.label_2.setText("")
        self.label_2.setObjectName("label_2")
        self.label_2.setPixmap(QtGui.QPixmap(QMini))
        self.label_2.setAlignment(QtCore.Qt.AlignCenter)
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        self.label_3.setGeometry(
            QtCore.QRect(Window_Image_width + 10 - Mini_Image_Size, Window_Image_height + 10 - Mini_Image_Size,
                         Mini_Image_Size, Mini_Image_Size))
        self.label_3.setStyleSheet("")
        self.label_3.setText("")
        self.label_3.setObjectName("label_3")
        self.label_3.setPixmap(QtGui.QPixmap("Main.png"))
        self.label_3.setAlignment(QtCore.Qt.AlignCenter)
        self.layoutWidget = QtWidgets.QWidget(self.centralwidget)
        self.layoutWidget.setGeometry(QtCore.QRect(10, Window_Image_height + 20, Window_Image_width, 31))
        self.layoutWidget.setObjectName("layoutWidget")
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.layoutWidget)
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.pushButton = QtWidgets.QPushButton(self.layoutWidget)
        self.pushButton.setObjectName("pushButton")

        if Index == 0:
            self.pushButton.setEnabled(False)
        self.pushButton.clicked.connect(self.Back)

        self.horizontalLayout.addWidget(self.pushButton)
        self.comboBox = QtWidgets.QComboBox(self.layoutWidget)
        self.comboBox.setObjectName("comboBox")

        self.comboBox.addItem("-")
        self.comboBox.addItem("A") #0
        self.comboBox.addItem("B") #1
        self.comboBox.addItem("C") #2
        self.comboBox.addItem("D") #3
        self.comboBox.addItem("E") #4
        self.comboBox.addItem("F") #5
        self.comboBox.addItem("G") #6
        self.comboBox.addItem("H") #7
        self.comboBox.addItem("I") #8
        self.comboBox.addItem("J") #9
        self.comboBox.addItem("K") #10
        self.comboBox.addItem("L") #11
        self.comboBox.addItem("M") #12
        self.comboBox.addItem("N") #13
        self.comboBox.addItem("O") #14
        self.comboBox.addItem("P") #15
        self.comboBox.addItem("Q") #16
        self.comboBox.addItem("R") #17
        self.comboBox.addItem("S") #18
        self.comboBox.addItem("T") #19
        self.comboBox.addItem("U") #20
        self.comboBox.addItem("V") #21
        self.comboBox.addItem("W") #22
        self.comboBox.addItem("X") #23
        self.comboBox.addItem("Y") #24
        self.comboBox.addItem("Z") #25
        self.comboBox.addItem("1") #26
        self.comboBox.addItem("2") #27
        self.comboBox.addItem("3") #28
        self.comboBox.addItem("4") #29
        self.comboBox.addItem("5") #30
        self.comboBox.addItem("6") #31
        self.comboBox.addItem("7") #32
        self.comboBox.addItem("8") #33
        self.comboBox.addItem("9") #34
        self.comboBox.addItem("0") #35

        self.comboBox.setCurrentIndex(self.Get_Combo_Index(Index))
        self.comboBox.activated[str].connect(self.ChangeText)


        self.horizontalLayout.addWidget(self.comboBox)
        self.pushButton_2 = QtWidgets.QPushButton(self.layoutWidget)
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton_2.clicked.connect(self.Next)
        self.horizontalLayout.addWidget(self.pushButton_2)
        self.pushButton_4 = QtWidgets.QPushButton(self.layoutWidget)
        self.pushButton_4.setEnabled(False)
        self.pushButton_4.clicked.connect(lambda : self.Train(MainWindow))
        self.pushButton_4.setObjectName("pushButton_4")
        self.horizontalLayout.addWidget(self.pushButton_4)
        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "Image to Text"))
        self.pushButton.setText(_translate("MainWindow", "Back"))
        self.pushButton_2.setText(_translate("MainWindow", "Next"))
        self.pushButton_4.setText(_translate("MainWindow", "Finish"))

    def Set_Image_In_Window(self, In):
        global QPMap_Rectangle, QMini
        OMG = image.copy()

        intX= Contours[In].intRectX
        intY= Contours[In].intRectY
        intW= Contours[In].intRectWidth
        intH= Contours[In].intRectHeight

        QPMap_Rectangle, QMini = Draw_Single_Rectangle(OMG, intX, intY, intW, intH)

    def Next(self):
        global Index
        Index = Index + 1
        if Index < Len_Contour:
            self.Set_Image_In_Window(Index)
            self.comboBox.setCurrentIndex(self.Get_Combo_Index(Index))
            self.label.setPixmap(QtGui.QPixmap(QPMap_Rectangle))
            self.label_2.setPixmap(QtGui.QPixmap(QMini))
            self.pushButton.setEnabled(True)

            if Index == Len_Contour - 1:
                self.pushButton_2.setEnabled(False)
                self.pushButton_4.setEnabled(True)

        else:
            pass

    def Back(self):
        global Index
        Index = Index - 1
        if Index > 0:
            self.Set_Image_In_Window(Index)
            self.comboBox.setCurrentIndex(self.Get_Combo_Index(Index))
            self.label.setPixmap(QtGui.QPixmap(QPMap_Rectangle))
            self.label_2.setPixmap(QtGui.QPixmap(QMini))
            self.pushButton_2.setEnabled(True)
            self.pushButton_4.setEnabled(False)

        elif Index == 0:
            self.Set_Image_In_Window(Index)
            self.comboBox.setCurrentIndex(self.Get_Combo_Index(Index))
            self.label.setPixmap(QtGui.QPixmap(QPMap_Rectangle))
            self.label_2.setPixmap(QtGui.QPixmap(QMini))
            self.pushButton.setEnabled(False)

    def Get_Combo_Index(self, In):
        if Text_Len == 0 or Text_Len <= In:
            a = 0
        else:
            a = ALPH.index(Text[In])
        return a

    def Train(self, MainWindow):
        global Text
        temp = []

        self.pushButton.setEnabled(False)
        self.comboBox.setEnabled(False)
        self.Index_Valid_Counter(Text)
        Text = Space_Remove(Text)

        c = 0
        for T in Text:
            temp.append(Contours[Index_validContoursWithData[c]])
            c = c + 1

        Result = Train_DB(Text, temp, image)
        print(Result)
        # if Result is True:
        #     import sys
        #     app = QtWidgets.QApplication(sys.argv)
        #     sys.exit(app.exec_())
            # self.window = QtWidgets.QMainWindow()
            # self.ui = Ui_MainWindow()
            # self.ui.setupUi(self.window)
            # self.window.show()

    def ChangeText(self, text):
        global Text, Text_Len
        le = Text_Len
        if Text_Len == 0 or Index >= le:
            Text = Text + text

        elif Index < le:
            Text = String_Index_Change(Text, Index, text)

        Text_Len = len(Text)

    def Index_Valid_Counter(self, Te):
        global Index_validContoursWithData
        cou = 0
        for I in Te:
            if I != "-":
                Index_validContoursWithData.append(cou)
                cou = cou + 1
            else:
                cou = cou + 1
