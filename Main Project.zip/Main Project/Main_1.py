from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QFileDialog, QMessageBox

import cv2
from Main_2 import Ui_SecondWindow
from F_ImageProcess import ResizeImage

Image_Location = None
Window_Image_width = 431
Window_Image_height = 241

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(431, 303)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("Main.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        MainWindow.setWindowIcon(icon)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setMinimumSize(QtCore.QSize(431, 283))
        self.centralwidget.setMaximumSize(QtCore.QSize(431, 283))
        self.centralwidget.setObjectName("centralwidget")
        self.ImageButton = QtWidgets.QPushButton(self.centralwidget)
        self.ImageButton.setGeometry(QtCore.QRect(9, 8, 411, 241))
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.MinimumExpanding, QtWidgets.QSizePolicy.MinimumExpanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.ImageButton.sizePolicy().hasHeightForWidth())
        self.ImageButton.setSizePolicy(sizePolicy)
        self.ImageButton.setMinimumSize(QtCore.QSize(0, 0))
        self.ImageButton.setSizeIncrement(QtCore.QSize(0, 0))
        self.ImageButton.setBaseSize(QtCore.QSize(1, 1))
        self.ImageButton.setStyleSheet("background-color: transparent;")
########################################################################################################################----ImageButton
        self.ImageButton.clicked.connect(self.Get_Image_Location)
        ################################################################################################################
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap("Add_Image.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.ImageButton.setIcon(icon1)
        self.ImageButton.setObjectName("ImageButton")
        self.Button = QtWidgets.QPushButton(self.centralwidget)
        self.Button.setGeometry(QtCore.QRect(10, 260, 411, 23))
        self.Button.setObjectName("Button")
########################################################################################################################----Button
        self.Button.clicked.connect(lambda : self.Next(MainWindow))
        ################################################################################################################
        self.Image = QtWidgets.QLabel(self.centralwidget)
        self.Image.setGeometry(QtCore.QRect(9, 9, 411, 241))
        self.Image.setStyleSheet("border-style: solid;\n"
"border-width: 1px;\n"
"border-color: rgb(225, 225, 225);")
        self.Image.setText("")
        self.Image.setPixmap(QtGui.QPixmap("Main.png"))
        self.Image.setAlignment(QtCore.Qt.AlignCenter)
        self.Image.setObjectName("Image")
        self.Button.raise_()
        self.Image.raise_()
        self.ImageButton.raise_()
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

########################################################################################################################----All functions
    def Get_Image_Location(self):
        global Image_Location
        location, _  = QFileDialog.getOpenFileName()
        if len(location) != 0:
            #Resize Image To The Window
            image = cv2.imread(location, 1)

            if image is not None:
                Image = ResizeImage(image, Window_Image_width, Window_Image_height)
                self.Image.setPixmap(QtGui.QPixmap(Image))
                # self.Image.setScaledContents(True)
                Image_Location = location

            else:
                self.Show_Error()

    def Next(self, MainWindow):
        if Image_Location is None:
            self.Show_Error()
        else:
            self.window = QtWidgets.QMainWindow()
            self.ui = Ui_SecondWindow(Image_Location)
            self.ui.setupUi(self.window)
            MainWindow.hide()
            self.window.show()



    def Show_Error(self):
        popup = QMessageBox()
        popup.setWindowTitle("Error")
        popup.setText("Please insert an image")
        popup.setIcon(QMessageBox.Information)
        popup.setStandardButtons(QMessageBox.Retry)
        popup.exec_()

    ####################################################################################################################

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "Image to Text"))
        self.ImageButton.setText(_translate("MainWindow", "Click to add Image"))
        self.Button.setText(_translate("MainWindow", "Next"))

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())