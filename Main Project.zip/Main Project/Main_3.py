from PyQt5 import QtCore, QtGui, QtWidgets
from F_ImageProcess import get_text
from Main_4 import Main4

Window_Image_width = 0
Window_Image_height = 0
Default_Max_Area_Count = 0
QPMap_Rectangle = None
contours = None
text = None
imgThresh = None
Image_Location = None
validContoursWithData = []

class Ui_MainWindow(object):
    def __init__(self, Location, Contours, QPMap, Image_width, Image_height, Max_Area_Count, Thresh):
        global Window_Image_width, Window_Image_height, Default_Max_Area_Count, QPMap_Rectangle, contours, text, imgThresh, Image_Location, validContoursWithData
        Image_Location = Location
        contours = Contours
        QPMap_Rectangle = QPMap
        Window_Image_width = Image_width
        Window_Image_height = Image_height
        Default_Max_Area_Count = Max_Area_Count
        imgThresh = Thresh
        text, validContoursWithData = get_text(contours, imgThresh)

        # if self.temp_text == 0:
        #     text = "\t \t \t \t\"NO DATA FOUND. Please train the software first.\""
        # else:
        #     text = self.temp_text


    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(Window_Image_width+20, Window_Image_height+31+5+31+25+20)
        MainWindow.setMinimumSize(QtCore.QSize(431, 303))
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("Main.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        MainWindow.setWindowIcon(icon)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setMinimumSize(QtCore.QSize(431, 283))
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(10, 0, Window_Image_width, 31))
        font = QtGui.QFont()
        font.setPointSize(14)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        self.label.setObjectName("label")
        self.widget = QtWidgets.QWidget(self.centralwidget)
        self.widget.setGeometry(QtCore.QRect(10, Window_Image_height+5+31+31, Window_Image_width, 25))
        self.widget.setObjectName("widget")
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.widget)
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.pushButton = QtWidgets.QPushButton(self.widget)
        self.pushButton.setObjectName("pushButton")
        self.horizontalLayout.addWidget(self.pushButton)
        self.pushButton_2 = QtWidgets.QPushButton(self.widget)
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton_2.clicked.connect(lambda : self.Not_Correct(MainWindow))
        self.horizontalLayout.addWidget(self.pushButton_2)
        self.widget1 = QtWidgets.QWidget(self.centralwidget)
        self.widget1.setGeometry(QtCore.QRect(10, 30, Window_Image_width, Window_Image_height+5+31))
        self.widget1.setObjectName("widget1")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.widget1)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.label_3 = QtWidgets.QLabel(self.widget1)
        self.label_3.setMinimumSize(QtCore.QSize(Window_Image_width, Window_Image_height))
        self.label_3.setStyleSheet("border-style: solid;\n"
"border-width: 1px;\n"
"border-color: rgb(225, 225, 225);")
        self.label_3.setText("")
        self.label_3.setObjectName("label_3")
        self.label_3.setPixmap(QtGui.QPixmap(QPMap_Rectangle))
        self.verticalLayout.addWidget(self.label_3)
        self.label_2 = QtWidgets.QLabel(self.widget1)
        self.label_2.setMinimumSize(QtCore.QSize(Window_Image_width, 31))
        self.label_2.setStyleSheet("border-style: solid;\n"
"background-color: rgb(255, 255, 255);\n"
"border-width: 1px;\n"
"border-color: rgb(225, 225, 225);")
        if text is None:
            self.label_2.setText("\t \t \t \t\"NO DATA FOUND. Please train the software first.\"")
        else:
            self.label_2.setText(text)

        self.label_2.setObjectName("label_2")
        self.verticalLayout.addWidget(self.label_2)
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "Image to Text"))
        self.label.setText(_translate("MainWindow", "Image to Text"))
        self.pushButton.setText(_translate("MainWindow", "Currect"))
        self.pushButton_2.setText(_translate("MainWindow", "Not Currect"))

    def Not_Correct(self, MainWindow):
        self.window = QtWidgets.QMainWindow()
        self.ui = Main4(Image_Location, contours, Window_Image_width, Window_Image_height, text, validContoursWithData)
        self.ui.setupUi(self.window)
        MainWindow.hide()
        self.window.show()
